# Instrucciones del Bot de Música para Discord

Este documento contiene instrucciones detalladas sobre cómo configurar y utilizar el bot de música para Discord.

## Primeros Pasos

### 1. Obtener un Token de Bot de Discord

1. Ve a [Discord Developer Portal](https://discord.com/developers/applications)
2. Haz clic en "New Application" y elige un nombre para tu aplicación
3. Ve a la pestaña "Bot" y haz clic en "Add Bot"
4. Bajo la sección de token, haz clic en "Reset Token" y copia el token generado
5. Habilita los siguientes intents en la sección "Privileged Gateway Intents":
   - Presence Intent
   - Server Members Intent
   - Message Content Intent

### 2. Configurar Variables de Entorno

Crea un archivo `.env` en la raíz del proyecto con la siguiente información:

```
DISCORD_TOKEN=tu_token_de_bot_aquí
CLIENT_ID=id_de_tu_aplicación
```

El CLIENT_ID se encuentra en la pestaña "General Information" de tu aplicación en el Discord Developer Portal.

### 3. Registrar Comandos Slash

Ejecuta el siguiente comando para registrar los comandos slash en Discord:

```bash
node src/deploy-commands.js
```

Este paso es necesario solo una vez, o cuando se realicen cambios en los comandos.

### 4. Iniciar el Bot

Inicia el bot usando:

```bash
node src/index.js
```

## Guía de Uso

### Agregar el Bot a un Servidor

Para invitar al bot a tu servidor, utiliza esta URL (reemplaza `CLIENT_ID` con el ID de tu aplicación):

```
https://discord.com/api/oauth2/authorize?client_id=CLIENT_ID&permissions=8&scope=bot%20applications.commands
```

### Comandos Disponibles

Todos los comandos usan el formato de slash commands de Discord:

| Comando | Función | Ejemplo |
|---------|---------|---------|
| `/play` | Reproduce música desde URL o busca | `/play https://youtu.be/dQw4w9WgXcQ` o `/play despacito` |
| `/pause` | Pausa la canción actual | `/pause` |
| `/resume` | Reanuda la reproducción | `/resume` |
| `/skip` | Salta a la siguiente canción | `/skip` |
| `/stop` | Detiene la reproducción | `/stop` |
| `/queue` | Muestra la cola actual | `/queue` |
| `/nowplaying` | Muestra la canción actual | `/nowplaying` |
| `/volume` | Ajusta el volumen (1-100) | `/volume 75` |

### Funcionalidades Detalladas

1. **Búsqueda de Música**:
   - Al usar `/play` con un término de búsqueda, el bot mostrará 5 resultados
   - Haz clic en uno de los botones numerados para seleccionar una canción
   - El bot reproducirá automáticamente la canción seleccionada

2. **Cola de Reproducción**:
   - Usa `/queue` para ver las canciones en cola
   - Si hay más de 10 canciones, puedes navegar entre páginas con los botones
   - La primera canción mostrada es la que se está reproduciendo actualmente

3. **Detalle de Reproducción**:
   - `/nowplaying` muestra información detallada de la canción actual
   - Incluye una barra de progreso visual
   - Muestra tiempo transcurrido y duración total

## Solución de Problemas

### El bot no se conecta a los canales de voz

- Verifica que el bot tenga permiso para unirse y hablar en canales de voz
- Asegúrate de estar en un canal de voz antes de usar comandos
- Reinicia el bot si el problema persiste

### Problemas de Reproducción de Audio

- Verifica que ffmpeg esté correctamente instalado
- Si no hay sonido, comprueba que el bot tenga el volumen adecuado con `/volume`
- Para problemas con fuentes específicas, intenta con otra plataforma

### Comandos no Disponibles

- Asegúrate de haber ejecutado `node src/deploy-commands.js`
- Verifica que el bot tenga permisos para usar comandos slash en el servidor
- Puede tomar hasta una hora para que los comandos nuevos aparezcan en Discord

### Error de Tokens

Si ves errores relacionados con tokens o autenticación:
1. Verifica que tu archivo `.env` tenga el token correcto
2. Regenera tu token en el Portal de Desarrolladores si es necesario
3. Reinicia el bot después de realizar cambios en el token