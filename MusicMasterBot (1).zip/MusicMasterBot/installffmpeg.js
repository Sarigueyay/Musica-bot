const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

console.log('Setting up ffmpeg for Discord music bot...');

// We'll create a symlink to ffmpeg-static's binary
const ffmpegStaticPath = require('ffmpeg-static');
console.log(`Found ffmpeg-static at: ${ffmpegStaticPath}`);

// Check if ffmpeg exists in PATH
exec('which ffmpeg', (error, stdout, stderr) => {
  if (error) {
    console.log('ffmpeg not found in PATH, creating symbolic link...');
    
    // Create the symlink from the static binary to a location in PATH
    try {
      // Make the binary executable
      fs.chmodSync(ffmpegStaticPath, '755');
      console.log('Changed permissions on ffmpeg binary');
      
      // Copy ffmpeg to a directory in PATH
      const targetPath = '/usr/local/bin/ffmpeg';
      fs.copyFileSync(ffmpegStaticPath, targetPath);
      console.log(`Copied ffmpeg to ${targetPath}`);
      
      // Test that it works
      exec('ffmpeg -version', (error, stdout, stderr) => {
        if (error) {
          console.error('Error running ffmpeg after installation:', error);
        } else {
          console.log('ffmpeg installed successfully!');
          console.log(stdout);
        }
      });
    } catch (err) {
      console.error('Failed to install ffmpeg:', err);
      
      // Try a different approach - use execPath directly
      console.log('Alternative: Using ffmpeg-static path directly...');
      
      // Save the path to a file that can be read by the bot
      fs.writeFileSync(
        path.join(__dirname, 'ffmpeg-path.txt'), 
        ffmpegStaticPath,
        'utf8'
      );
      console.log('Saved ffmpeg path to ffmpeg-path.txt');
    }
  } else {
    console.log('ffmpeg is already available in PATH:');
    console.log(stdout.trim());
  }
});