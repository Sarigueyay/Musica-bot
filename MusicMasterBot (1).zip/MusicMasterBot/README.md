# Bot de Música para Discord

Un completo bot de música para Discord con soporte para múltiples plataformas y una interfaz de usuario interactiva.

## Características

- 🎵 Reproduce música desde **YouTube**, **Spotify** y **SoundCloud**
- 🔍 Busca canciones con selección de múltiples resultados
- 🎮 Controles completos: pausar, reanudar, saltar, detener, etc.
- 📊 Muestra cola de reproducción con paginación interactiva
- 🎛️ Control de volumen integrado
- 🎯 Interfaz de usuario con botones interactivos

## Comandos Disponibles

El bot utiliza comandos de barra diagonal (slash commands):

- `/play <canción>` - Reproduce una canción o la añade a la cola
  - Acepta URLs directas o términos de búsqueda
  - Al usar un término de búsqueda, muestra 5 resultados para elegir
- `/pause` - Pausa la canción actual
- `/resume` - Reanuda la reproducción
- `/skip` - Salta a la siguiente canción
- `/stop` - Detiene la reproducción y limpia la cola
- `/queue [página]` - Muestra la cola actual con paginación
- `/nowplaying` - Muestra información detallada de la canción actual
- `/volume <nivel>` - Ajusta el volumen (1-100)

## Configuración

### Requisitos Previos

1. Node.js 16.9.0 o superior
2. Un bot de Discord con los intents correctos habilitados
3. Token de bot de Discord

### Pasos de Configuración

1. Clona este repositorio
2. Ejecuta `npm install` para instalar las dependencias
3. Crea un archivo `.env` en la raíz con el siguiente contenido:
   ```
   DISCORD_TOKEN=tu_token_de_discord_aquí
   CLIENT_ID=id_de_aplicación_del_bot
   ```
4. Ejecuta `node src/deploy-commands.js` para registrar los comandos
5. Inicia el bot con `node src/index.js`

### Invitar al Bot

Para invitar al bot a tu servidor, utiliza la siguiente URL (reemplaza `CLIENT_ID` con el ID de tu aplicación):
```
https://discord.com/api/oauth2/authorize?client_id=CLIENT_ID&permissions=8&scope=bot%20applications.commands
```

## Parámetros Técnicos

- **Bibliotecas principales:**
  - discord.js - Para la integración con Discord
  - DisTube - Para la funcionalidad de streaming de música
  - @discordjs/voice - Para el manejo de audio
  - ffmpeg-static - Para procesamiento de audio

## Solución de Problemas

- **El bot no reproduce audio:** Verifica que ffmpeg esté correctamente instalado
- **Comandos no disponibles:** Asegúrate de haber ejecutado el script deploy-commands.js
- **Error de permisos:** Verifica que el bot tenga los permisos necesarios en el servidor

## Créditos

Este bot utiliza las siguientes tecnologías:

- [discord.js](https://discord.js.org/)
- [DisTube](https://distube.js.org/)
- [yt-dlp](https://github.com/yt-dlp/yt-dlp)