
# --- Servidor Flask para mantener el bot vivo ---
from flask import Flask
from threading import Thread
import discord

app = Flask('')

@app.route('/')
def home():
    return "El bot está activo!"

def run():
    app.run(host='0.0.0.0', port=3000)  # Asegúrate de usar el puerto 3000, que es el recomendado en Replit.

def keep_alive():
    t = Thread(target=run)
    t.start()

# --- Código básico del bot de Discord ---
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'Bot conectado como {client.user}')

@client.event
async def on_message(message):
    if message.author == client.user:
        return
    if message.content.lower() == "hola":
        await message.channel.send("¡Hola, parcero!")

# --- Mantener vivo + arrancar bot ---
keep_alive()
client.run("MTM3MDIyMTcyMDMwODI4OTYxNg.GcOiU4.0wwwVQkKYk5c_qMDwgPJyIEu2mMfSguwuNNDNg")  # Ya lo pegaste aquí