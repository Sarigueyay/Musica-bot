require('dotenv').config();
// También intentamos cargar configuraciones específicas del servidor si existen
try {
  require('dotenv').config({ path: '.env.guild' });
} catch (e) {
  // Si no existe, continuamos normalmente
}
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(commandsPath);

for (const folder of commandFolders) {
  const folderPath = path.join(commandsPath, folder);
  const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
  
  for (const file of commandFiles) {
    const filePath = path.join(folderPath, file);
    const command = require(filePath);
    
    if ('data' in command && 'execute' in command) {
      commands.push(command.data.toJSON());
    } else {
      console.log(`[WARNING] The command at ${filePath} is missing required "data" or "execute" property.`);
    }
  }
}

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log(`Started refreshing ${commands.length} application (/) commands.`);

    // Prompt for server ID if not available
    const readline = require('readline').createInterface({
      input: process.stdin,
      output: process.stdout
    });

    // The put method is used to fully refresh all commands
    let data;
    
    if (process.env.GUILD_ID) {
      // Guild commands - faster for development, instant update
      data = await rest.put(
        Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
        { body: commands },
      );
      console.log(`Successfully reloaded ${data.length} guild application (/) commands.`);
    } else {
      // Ask for server ID
      console.log("RECOMENDACIÓN: Para que los comandos aparezcan inmediatamente, ingresa el ID de tu servidor (GUILD_ID)");
      console.log("Para obtener el ID de tu servidor, activa el Modo Desarrollador en Discord (Configuración > Avanzado)");
      console.log("Luego haz clic derecho en tu servidor y selecciona 'Copiar ID'");
      console.log("Si no ingresas un ID, los comandos se registrarán globalmente (pueden tardar hasta 1 hora)");
      console.log("Presiona Enter para registrar globalmente o ingresa el ID de tu servidor:");
      
      readline.question('GUILD_ID (opcional): ', async (guildId) => {
        readline.close();
        
        if (guildId && guildId.trim() !== '') {
          // Guild commands - faster for development, instant update
          data = await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, guildId.trim()),
            { body: commands },
          );
          console.log(`Successfully reloaded ${data.length} guild application (/) commands.`);
          console.log(`Los comandos estarán disponibles inmediatamente en tu servidor.`);
        } else {
          // Global commands - takes up to an hour to update, but works in all guilds
          data = await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commands },
          );
          console.log(`Successfully reloaded ${data.length} global application (/) commands.`);
          console.log(`NOTA: Los comandos globales pueden tardar hasta 1 hora en aparecer en todos los servidores.`);
        }
      });
      return; // Exit early as we're handling the async readline
    }
  } catch (error) {
    console.error(error);
  }
})();
