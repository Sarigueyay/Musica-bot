const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`Ready! Logged in as ${client.user.tag}`);
    
    // Establecer actividad inicial
    client.user.setActivity('/play', { type: ActivityType.Listening });
    
    // Configurar actividades rotativas
    const activities = [
      { name: '/play', type: ActivityType.Listening },
      { name: 'música', type: ActivityType.Listening },
      { name: 'tus comandos', type: ActivityType.Listening },
      { name: '/help', type: ActivityType.Playing },
      { name: 'Spotify, YouTube y SoundCloud', type: ActivityType.Streaming, url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
      { name: 'la mejor música', type: ActivityType.Playing },
      { name: 'con sonidos', type: ActivityType.Playing }
    ];
    
    let currentIndex = 0;
    
    // Cambiar la actividad cada 30 segundos
    setInterval(() => {
      const activity = activities[currentIndex];
      client.user.setActivity(activity.name, { 
        type: activity.type,
        url: activity.url || null 
      });
      
      // Avanzar al siguiente índice, volviendo al principio si llegamos al final
      currentIndex = (currentIndex + 1) % activities.length;
    }, 30000); // 30 segundos
  }
};
