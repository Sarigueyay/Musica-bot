const { createEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'error',
  once: false,
  async execute(channel, error) {
    console.error('DisTube error:', error);
    
    if (channel) {
      await channel.send({
        embeds: [createEmbed('error', `An error occurred: ${error.message}`)]
      }).catch(console.error);
    }
  }
};
