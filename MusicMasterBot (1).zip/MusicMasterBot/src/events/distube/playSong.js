const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'playSong',
  once: false,
  async execute(queue, song) {
    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🎵 Now Playing')
      .setDescription(`[${song.name}](${song.url})`)
      .addFields(
        { name: 'Duration', value: song.formattedDuration, inline: true },
        { name: 'Requested by', value: `${song.user}`, inline: true }
      )
      .setThumbnail(song.thumbnail);
      
    // Add source information
    if (song.url.includes('youtube.com') || song.url.includes('youtu.be')) {
      embed.addFields({ name: 'Source', value: '📺 YouTube', inline: true });
    } else if (song.url.includes('spotify.com')) {
      embed.addFields({ name: 'Source', value: '💚 Spotify', inline: true });
    } else if (song.url.includes('soundcloud.com')) {
      embed.addFields({ name: 'Source', value: '🧡 SoundCloud', inline: true });
    }
      
    queue.textChannel.send({ embeds: [embed] }).catch(console.error);
  }
};
