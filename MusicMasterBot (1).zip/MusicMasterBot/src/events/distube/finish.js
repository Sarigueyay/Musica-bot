const { createEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'finish',
  once: false,
  async execute(queue) {
    const embed = createEmbed('info', '🎵 Queue has ended! No more songs to play.');
    queue.textChannel.send({ embeds: [embed] }).catch(console.error);
  }
};
