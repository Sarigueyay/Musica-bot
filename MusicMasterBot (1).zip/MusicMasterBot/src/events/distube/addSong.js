const { createEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'addSong',
  once: false,
  async execute(queue, song) {
    const embed = createEmbed(
      'success', 
      `✅ Added to queue: [${song.name}](${song.url}) - \`${song.formattedDuration}\`\nRequested by: ${song.user}`
    );
    
    queue.textChannel.send({ embeds: [embed] }).catch(console.error);
  }
};
