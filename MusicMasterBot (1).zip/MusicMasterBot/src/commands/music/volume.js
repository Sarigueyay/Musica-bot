const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Changes the volume of the music')
    .addIntegerOption(option => 
      option.setName('percentage')
        .setDescription('Volume percentage (0-100)')
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(100)),

  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    const voiceChannel = interaction.member.voice.channel;
    const volume = interaction.options.getInteger('percentage');
    
    // Check if the user is in a voice channel
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [createEmbed('error', 'You need to be in a voice channel to use this command!')],
        ephemeral: true
      });
    }
    
    // Check if there's music playing
    if (!queue) {
      return interaction.reply({
        embeds: [createEmbed('error', 'There is nothing playing!')],
        ephemeral: true
      });
    }
    
    try {
      queue.setVolume(volume);
      interaction.reply({
        embeds: [createEmbed('success', `🔊 Volume set to ${volume}%`)]
      });
    } catch (error) {
      console.error(error);
      interaction.reply({
        embeds: [createEmbed('error', `An error occurred: ${error.message}`)],
        ephemeral: true
      });
    }
  }
};
