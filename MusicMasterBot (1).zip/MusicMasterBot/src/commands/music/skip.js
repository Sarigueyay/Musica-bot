const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Skips the current song'),

  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    const voiceChannel = interaction.member.voice.channel;
    
    // Check if the user is in a voice channel
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [createEmbed('error', 'You need to be in a voice channel to use this command!')],
        ephemeral: true
      });
    }
    
    // Check if there's music playing
    if (!queue) {
      return interaction.reply({
        embeds: [createEmbed('error', 'There is nothing in the queue!')],
        ephemeral: true
      });
    }

    try {
      const song = queue.songs[0];
      await queue.skip();
      interaction.reply({
        embeds: [createEmbed('success', `⏭️ Skipped: ${song.name}`)]
      });
    } catch (error) {
      console.error(error);
      if (error.message === "There's no song to skip.") {
        interaction.reply({
          embeds: [createEmbed('info', 'There are no more songs in the queue!')]
        });
      } else {
        interaction.reply({
          embeds: [createEmbed('error', `An error occurred: ${error.message}`)],
          ephemeral: true
        });
      }
    }
  }
};
