const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createEmbed, createQueueEmbed, formatDuration } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Shows the current music queue')
    .addIntegerOption(option => 
      option.setName('page')
        .setDescription('Page number of the queue')
        .setRequired(false)),

  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    const voiceChannel = interaction.member.voice.channel;
    
    // Check if the user is in a voice channel
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [createEmbed('error', 'You need to be in a voice channel to use this command!')],
        ephemeral: true
      });
    }
    
    // Check if there's music playing
    if (!queue || !queue.songs || queue.songs.length === 0) {
      return interaction.reply({
        embeds: [createEmbed('info', 'There is nothing in the queue!')],
        ephemeral: true
      });
    }
    
    const pageOption = interaction.options.getInteger('page');
    const songsPerPage = 10;
    const totalPages = Math.ceil(queue.songs.length / songsPerPage) || 1;
    const page = pageOption ? Math.min(Math.max(pageOption, 1), totalPages) : 1;
    
    // Si solo hay una página, o estamos usando nuestra utilidad de cola, usar createQueueEmbed
    if (totalPages === 1 || !pageOption) {
      return interaction.reply({ embeds: [createQueueEmbed(queue)] });
    }
    
    // Para paginación, continuamos con la lógica personalizada
    const startIndex = (page - 1) * songsPerPage;
    const endIndex = Math.min(startIndex + songsPerPage, queue.songs.length);
    
    const currentSong = queue.songs[0];
    
    // Create a formatted list of songs for the current page
    let queueString = '';
    
    // Si estamos en la primera página, incluir la canción actual
    if (page === 1) {
      queueString += `**Now Playing:** [${currentSong.name}](${currentSong.url}) - \`${formatDuration(currentSong.duration)}\`\n\n`;
    }
    
    // Add the rest of the songs for this page
    const songsToDisplay = page === 1 
      ? queue.songs.slice(1, endIndex) 
      : queue.songs.slice(startIndex, endIndex);
    
    if (songsToDisplay.length > 0) {
      queueString += songsToDisplay
        .map((song, index) => {
          const displayIndex = page === 1 ? index + 1 : startIndex + index;
          return `**${displayIndex}.** [${song.name}](${song.url}) - \`${formatDuration(song.duration)}\``;
        })
        .join('\n');
    } else {
      queueString += 'No more songs in queue.';
    }
    
    // Calculate queue duration
    const queueDuration = queue.songs.reduce((acc, song) => acc + (song.duration || 0), 0);
    
    // Crear un embed con la información de la cola
    const embed = createEmbed('info', queueString)
      .setTitle('🎶 Music Queue')
      .setThumbnail(currentSong.thumbnail || null)
      .setFooter({ 
        text: `Page ${page}/${totalPages} • ${queue.songs.length} songs • ${formatDuration(queueDuration)} total duration`
      });
    
    // Si hay múltiples páginas, añadir botones de navegación
    const components = [];
    
    if (totalPages > 1) {
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('queue_first')
            .setLabel('◀◀ First')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === 1),
          new ButtonBuilder()
            .setCustomId('queue_prev')
            .setLabel('◀ Previous')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === 1),
          new ButtonBuilder()
            .setCustomId('queue_next')
            .setLabel('Next ▶')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === totalPages),
          new ButtonBuilder()
            .setCustomId('queue_last')
            .setLabel('Last ▶▶')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(page === totalPages)
        );
      
      components.push(row);
    }
    
    const response = await interaction.reply({ 
      embeds: [embed], 
      components: components,
      fetchReply: true
    });
    
    // Si hay botones, configurar un collector para navegación
    if (components.length > 0) {
      const collector = response.createMessageComponentCollector({ 
        time: 60000 // 60 segundos
      });
      
      collector.on('collect', async i => {
        // Verificar que es el usuario que ejecutó el comando
        if (i.user.id !== interaction.user.id) {
          return i.reply({
            content: 'You cannot use these buttons.',
            ephemeral: true
          });
        }
        
        // Determinar la nueva página según el botón
        let newPage = page;
        
        switch (i.customId) {
          case 'queue_first':
            newPage = 1;
            break;
          case 'queue_prev':
            newPage = Math.max(1, page - 1);
            break;
          case 'queue_next':
            newPage = Math.min(totalPages, page + 1);
            break;
          case 'queue_last':
            newPage = totalPages;
            break;
        }
        
        // Si la página no cambió, no hacer nada
        if (newPage === page) {
          await i.deferUpdate();
          return;
        }
        
        // Ejecutar el comando con la nueva página
        await i.deferUpdate();
        
        // Crear un nuevo mensaje de interacción con la página actualizada
        const newInteraction = { ...interaction };
        newInteraction.options = {
          getInteger: (name) => name === 'page' ? newPage : null
        };
        
        // Ejecutar el comando de nuevo
        await this.execute(newInteraction);
      });
      
      collector.on('end', async () => {
        // Desactivar los botones cuando expire
        const disabledRow = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('queue_first')
              .setLabel('◀◀ First')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(true),
            new ButtonBuilder()
              .setCustomId('queue_prev')
              .setLabel('◀ Previous')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(true),
            new ButtonBuilder()
              .setCustomId('queue_next')
              .setLabel('Next ▶')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(true),
            new ButtonBuilder()
              .setCustomId('queue_last')
              .setLabel('Last ▶▶')
              .setStyle(ButtonStyle.Primary)
              .setDisabled(true)
          );
        
        try {
          await interaction.editReply({ components: [disabledRow] });
        } catch (error) {
          // Ignorar errores de edición después del tiempo límite
        }
      });
    }
  }
};
