const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { createEmbed, createSearchResultsEmbed, formatDuration } = require('../../utils/embeds');
const { searchYouTube } = require('../../utils/youtube-search');

// Función para obtener el emoji según la fuente del video
function getEmoji(source) {
  if (!source) return '🎵';
  
  switch (source.toLowerCase()) {
    case 'youtube':
      return '📺';
    case 'spotify':
      return '💚';
    case 'soundcloud':
      return '🟠';
    default:
      return '🎵';
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Plays a song or adds it to the queue')
    .addStringOption(option => 
      option.setName('song')
        .setDescription('The song to play (URL or search term)')
        .setRequired(true)),

  async execute(interaction) {
    const query = interaction.options.getString('song');
    const voiceChannel = interaction.member.voice.channel;
    
    // Check if the user is in a voice channel
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [createEmbed('error', 'You need to be in a voice channel to use this command!')],
        ephemeral: true
      });
    }

    // Check if the bot has permission to join and speak in the voice channel
    const permissions = voiceChannel.permissionsFor(interaction.client.user);
    if (!permissions.has('Connect') || !permissions.has('Speak')) {
      return interaction.reply({
        embeds: [createEmbed('error', 'I need permission to join and speak in your voice channel!')],
        ephemeral: true
      });
    }

    await interaction.deferReply();
    
    try {
      // If it's a URL (YouTube, Spotify, SoundCloud), play directly
      if (
        query.includes('youtube.com') || 
        query.includes('youtu.be') || 
        query.includes('spotify.com') || 
        query.includes('soundcloud.com')
      ) {
        await interaction.client.distube.play(voiceChannel, query, {
          member: interaction.member,
          textChannel: interaction.channel
        });
        
        return await interaction.editReply({
          embeds: [createEmbed('success', `⏱️ Loading your track...`)]
        });
      }
      
      // Informamos al usuario que estamos buscando
      await interaction.editReply({
        embeds: [createEmbed('info', `🔎 Searching for: "${query}" on YouTube...`)]
      });
      
      // Realizar búsqueda con nuestra utilidad personalizada
      const searchResults = await searchYouTube(query, 5); // Buscar 5 resultados
      
      if (!searchResults || searchResults.length === 0) {
        return await interaction.editReply({
          embeds: [createEmbed('error', `No results found for: "${query}"`)]
        });
      }
      
      // Crear embed con los resultados de la búsqueda
      const resultsEmbed = createSearchResultsEmbed(searchResults, query);
      
      // Crear filas de botones, máximo 4 botones en la primera fila + cancelar
      const row1 = new ActionRowBuilder();
      
      // Primera fila: opciones 1-4
      const maxButtonsFirstRow = Math.min(4, searchResults.length);
      for (let i = 0; i < maxButtonsFirstRow; i++) {
        row1.addComponents(
          new ButtonBuilder()
            .setCustomId(`search_${i}`)
            .setLabel(`${i + 1}`)
            .setStyle(ButtonStyle.Primary)
        );
      }
      
      // Añadir botón de cancelar a la primera fila
      row1.addComponents(
        new ButtonBuilder()
          .setCustomId('search_cancel')
          .setLabel('Cancel')
          .setStyle(ButtonStyle.Danger)
      );
      
      // Si hay 5 resultados y solo mostramos 4 en la primera fila, no necesitamos segunda fila
      const components = [row1];
      const response = await interaction.editReply({
        embeds: [resultsEmbed],
        components: components
      });
      
      // Crear collector para esperar respuesta del usuario
      const collector = response.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 30000 // 30 segundos
      });
      
      collector.on('collect', async i => {
        // Verificar que es el mismo usuario que ejecutó el comando
        if (i.user.id !== interaction.user.id) {
          return i.reply({
            content: 'This is not your search result!',
            ephemeral: true
          });
        }
        
        // Detener el collector
        collector.stop();
        
        // Si es cancelar, mostrar mensaje y terminar
        if (i.customId === 'search_cancel') {
          await i.update({
            embeds: [createEmbed('info', 'Search canceled')],
            components: []
          });
          return;
        }
        
        // Obtener el índice del resultado seleccionado
        const selectedIndex = parseInt(i.customId.split('_')[1]);
        const selectedResult = searchResults[selectedIndex];
        
        // Actualizar mensaje para mostrar la selección
        await i.update({
          embeds: [createEmbed('success', `Selected: **${selectedResult.title}**\n⏱️ Loading your track...`)],
          components: []
        });
        
        // Reproducir la canción seleccionada
        await interaction.client.distube.play(voiceChannel, selectedResult.url, {
          member: interaction.member,
          textChannel: interaction.channel
        });
      });
      
      // Cuando el tiempo expira y no hay selección
      collector.on('end', async collected => {
        if (collected.size === 0) {
          await interaction.editReply({
            embeds: [createEmbed('info', 'Search timed out - no selection was made')],
            components: []
          });
        }
      });
    } catch (error) {
      console.error('Error in play command:', error);
      await interaction.editReply({
        embeds: [createEmbed('error', `An error occurred: ${error.message}`)]
      });
    }
  }
};
