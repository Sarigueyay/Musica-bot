const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pause')
    .setDescription('Pauses the current song'),

  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    const voiceChannel = interaction.member.voice.channel;
    
    // Check if the user is in a voice channel
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [createEmbed('error', 'You need to be in a voice channel to use this command!')],
        ephemeral: true
      });
    }
    
    // Check if there's music playing
    if (!queue) {
      return interaction.reply({
        embeds: [createEmbed('error', 'There is nothing playing!')],
        ephemeral: true
      });
    }

    // Check if the queue is already paused
    if (queue.paused) {
      return interaction.reply({
        embeds: [createEmbed('info', 'The music is already paused! Use `/resume` to continue playing.')],
        ephemeral: true
      });
    }
    
    try {
      queue.pause();
      interaction.reply({
        embeds: [createEmbed('success', '⏸️ Paused the music')]
      });
    } catch (error) {
      console.error(error);
      interaction.reply({
        embeds: [createEmbed('error', `An error occurred: ${error.message}`)],
        ephemeral: true
      });
    }
  }
};
