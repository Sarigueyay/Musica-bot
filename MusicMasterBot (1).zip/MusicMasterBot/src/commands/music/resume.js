const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Resumes the current paused song'),

  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    const voiceChannel = interaction.member.voice.channel;
    
    // Check if the user is in a voice channel
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [createEmbed('error', 'You need to be in a voice channel to use this command!')],
        ephemeral: true
      });
    }
    
    // Check if there's music in the queue
    if (!queue) {
      return interaction.reply({
        embeds: [createEmbed('error', 'There is nothing in the queue!')],
        ephemeral: true
      });
    }

    // Check if the queue is paused
    if (!queue.paused) {
      return interaction.reply({
        embeds: [createEmbed('info', 'The music is already playing!')],
        ephemeral: true
      });
    }
    
    try {
      queue.resume();
      interaction.reply({
        embeds: [createEmbed('success', '▶️ Resumed the music')]
      });
    } catch (error) {
      console.error(error);
      interaction.reply({
        embeds: [createEmbed('error', `An error occurred: ${error.message}`)],
        ephemeral: true
      });
    }
  }
};
