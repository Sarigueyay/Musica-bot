const { SlashCommandBuilder } = require('discord.js');
const { createEmbed, createSongEmbed, formatDuration } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nowplaying')
    .setDescription('Shows information about the currently playing song'),

  async execute(interaction) {
    const queue = interaction.client.distube.getQueue(interaction.guildId);
    const voiceChannel = interaction.member.voice.channel;
    
    // Check if the user is in a voice channel
    if (!voiceChannel) {
      return interaction.reply({
        embeds: [createEmbed('error', 'You need to be in a voice channel to use this command!')],
        ephemeral: true
      });
    }
    
    // Check if there's music playing
    if (!queue || !queue.songs || queue.songs.length === 0) {
      return interaction.reply({
        embeds: [createEmbed('info', 'There is nothing playing right now!')],
        ephemeral: true
      });
    }
    
    const song = queue.songs[0];
    const currentTime = queue.currentTime;
    const duration = song.duration;
    
    // Create a progress bar
    const progressBar = createProgressBar(currentTime, duration);
    
    // Crear un banner personalizado más atractivo
    const bannerIcons = ['🎧', '🎵', '🎶', '🎸', '🥁', '🎹', '🎷', '🎺', '🎻', '🪕', '🔊'];
    // Seleccionar un ícono aleatorio para dar sensación de animación
    const randomIcon = bannerIcons[Math.floor(Math.random() * bannerIcons.length)];
    
    // Crear un título con elementos visuales
    const bannerTitle = `${randomIcon} NOW PLAYING ${randomIcon}`;
    
    // Añadir estrellas para dar sensación de animación
    const starRating = '⭐'.repeat(Math.floor(Math.random() * 3) + 3); // Entre 3 y 5 estrellas
    
    // Crear un marco visual para el título de la canción
    const songTitle = `💫 ${song.name} 💫`;
    
    // Crear una descripción más elaborada
    const sourceInfo = `${getSourceIcon(song.url)} Source: ${getSource(song.url)}`;
    const requestedBy = song.user ? `👤 Requested by: ${song.user}` : '';
    const richDescription = [
      `[${songTitle}](${song.url})`,
      sourceInfo,
      requestedBy,
      `${starRating}`
    ].filter(Boolean).join('\n');
    
    // Crear el embed con apariencia de banner animado
    const npEmbed = createSongEmbed(song, true)
      .setTitle(bannerTitle)
      .setDescription(richDescription)
      .addFields({
        name: '▶️ Progress Bar 🔊',
        value: `\`${formatDuration(currentTime)} / ${formatDuration(duration)}\`\n${progressBar}`, 
        inline: false
      });
    
    // Add volume information with visual element
    if (queue.volume) {
      const volumeBar = createVolumeBar(queue.volume);
      npEmbed.addFields({ 
        name: '🔊 Volume Control', 
        value: `${volumeBar} ${queue.volume}%`, 
        inline: true 
      });
    }
    
    // Add queue position information if there are more songs in the queue
    if (queue.songs.length > 1) {
      npEmbed.addFields({ 
        name: '📋 Queue Info', 
        value: `🎵 Playing 1 of ${queue.songs.length} songs 🎵`, 
        inline: true 
      });
    }
    
    // Añadir un footer con timestamp para dar sensación de actualización
    npEmbed.setFooter({ 
      text: `🎧 Discord Music Bot • Updated at ${new Date().toLocaleTimeString()}` 
    });
    
    // Usar un color aleatorio para dar sensación de cambio/animación
    const colors = [0x5865F2, 0xEB459E, 0x57F287, 0xFEE75C, 0xED4245];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    npEmbed.setColor(randomColor);
    
    interaction.reply({ embeds: [npEmbed] });
  }
};

// Create a volume bar visualization
function createVolumeBar(volume) {
  // Volume va de 0 a 100
  const barLength = 10;
  const filledLength = Math.round((volume / 100) * barLength);
  
  // Elegir el emoji según el nivel
  let volumeIcon;
  if (volume < 30) volumeIcon = '🔈';
  else if (volume < 70) volumeIcon = '🔉';
  else volumeIcon = '🔊';
  
  // Crear la barra visual
  const filledBlock = '█';
  const emptyBlock = '░';
  
  let volumeBar = volumeIcon + ' ';
  volumeBar += filledBlock.repeat(filledLength);
  volumeBar += emptyBlock.repeat(barLength - filledLength);
  
  return volumeBar;
}

// Create a text-based animated progress bar
function createProgressBar(currentTime, duration) {
  if (!duration) return '▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 🔘 LIVE';
  
  const barLength = 15;
  const progress = Math.round((currentTime / duration) * barLength);
  
  // Crear elementos animados con diferentes caracteres
  const filledBlock = '█'; // Bloque completo para la parte completada
  const emptyBlock = '░'; // Bloque vacío para la parte restante
  
  // Elegir un indicador de posición basado en el porcentaje
  let positionIcon;
  const percent = (currentTime / duration) * 100;
  
  if (percent < 10) positionIcon = '🔥'; // Inicio
  else if (percent < 30) positionIcon = '⏩'; // Progreso inicial
  else if (percent < 70) positionIcon = '🎵'; // Medio
  else if (percent < 90) positionIcon = '⏭️'; // Casi terminando
  else positionIcon = '🏁'; // Final
  
  // Crear la barra con colores y animación
  let progressBar = '';
  
  // Parte completada
  progressBar += filledBlock.repeat(progress);
  
  // Indicador de posición
  progressBar += positionIcon;
  
  // Parte restante
  progressBar += emptyBlock.repeat(barLength - progress);
  
  return progressBar;
}

// Determine the source of the song
function getSource(url) {
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    return 'YouTube';
  } else if (url.includes('spotify.com')) {
    return 'Spotify';
  } else if (url.includes('soundcloud.com')) {
    return 'SoundCloud';
  } else {
    return 'Unknown';
  }
}

// Get icon for the source
function getSourceIcon(url) {
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    return '📺';
  } else if (url.includes('spotify.com')) {
    return '💚';
  } else if (url.includes('soundcloud.com')) {
    return '🧡';
  } else {
    return '🎵';
  }
}
