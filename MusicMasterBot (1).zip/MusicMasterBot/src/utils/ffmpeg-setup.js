const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

/**
 * Configura la ruta de ffmpeg en el ambiente
 * @returns {string} Ruta a ffmpeg
 */
function setupFFmpeg() {
  try {
    console.log('Setting up ffmpeg for DisTube...');
    
    // Primero, intentamos con ffmpeg-static
    const ffmpegStatic = require('ffmpeg-static');
    console.log(`Found ffmpeg-static at: ${ffmpegStatic}`);
    
    if (fs.existsSync(ffmpegStatic)) {
      // Asegurar permisos de ejecución
      fs.chmodSync(ffmpegStatic, 0o755);
      console.log('Changed permissions on ffmpeg binary');
      
      // Configurar variables de entorno
      process.env.FFMPEG_PATH = ffmpegStatic;
      
      // Add to PATH
      const ffmpegDir = path.dirname(ffmpegStatic);
      process.env.PATH = `${ffmpegDir}:${process.env.PATH}`;
      
      // Crear symlinks en ubicaciones esperadas
      
      // 1. Guardar la ruta en un archivo para futuras referencias
      fs.writeFileSync(path.join(process.cwd(), 'ffmpeg-path.txt'), ffmpegStatic, 'utf8');
      
      // 2. Symlink/copy to standard locations
      try {
        const binDir = path.join(process.cwd(), 'node_modules', '.bin');
        if (!fs.existsSync(binDir)) {
          fs.mkdirSync(binDir, { recursive: true });
        }
        
        const binPath = path.join(binDir, 'ffmpeg');
        if (!fs.existsSync(binPath)) {
          try {
            fs.symlinkSync(ffmpegStatic, binPath);
            console.log(`Created symlink to ${binPath}`);
          } catch (e) {
            fs.copyFileSync(ffmpegStatic, binPath);
            fs.chmodSync(binPath, 0o755);
            console.log(`Copied to ${binPath}`);
          }
        }
      } catch (e) {
        console.log('Warning: Could not create ffmpeg symlinks:', e.message);
      }
      
      // Intentar determinar si carga correctamente
      try {
        // Ejecutar ffmpeg -version
        exec(`${ffmpegStatic} -version`, (error, stdout, stderr) => {
          if (error) {
            console.log('Warning: ffmpeg test failed:', error.message);
          } else {
            console.log('ffmpeg test successful');
          }
        });
      } catch (e) {
        console.log('Warning: Could not test ffmpeg:', e.message);
      }
      
      return ffmpegStatic;
    }
  } catch (error) {
    console.log('Error setting up ffmpeg:', error.message);
  }
  
  // Si llegamos aquí, no pudimos configurar ffmpeg
  console.log('WARNING: Could not properly set up ffmpeg');
  return null;
}

module.exports = { setupFFmpeg };