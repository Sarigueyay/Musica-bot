const { EmbedBuilder } = require('discord.js');

/**
 * Creates a standardized embed for the bot
 * @param {string} type - The type of embed ('success', 'error', 'info')
 * @param {string} message - The message to display
 * @returns {EmbedBuilder} The created embed
 */
function createEmbed(type, message) {
  let color;
  let title;
  
  switch (type) {
    case 'success':
      color = 0x57F287; // Discord green
      title = '✅ Success';
      break;
    case 'error':
      color = 0xED4245; // Discord red
      title = '❌ Error';
      break;
    case 'info':
    default:
      color = 0x5865F2; // Discord blurple
      title = 'ℹ️ Information';
      break;
  }
  
  return new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(message)
    .setTimestamp();
}

/**
 * Creates a song embed for the nowplaying/queue commands
 * @param {Object} song - The song object from DisTube
 * @param {boolean} isNowPlaying - Whether this is the currently playing song
 * @returns {EmbedBuilder} The created embed
 */
function createSongEmbed(song, isNowPlaying = false) {
  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(isNowPlaying ? '🎵 Now Playing' : '🎵 Song Info')
    .setDescription(`[${song.name}](${song.url})`)
    .addFields(
      { name: 'Duration', value: formatDuration(song.duration), inline: true },
      { name: 'Requested by', value: song.user ? song.user.toString() : 'Unknown', inline: true }
    );
  
  if (song.thumbnail) {
    embed.setThumbnail(song.thumbnail);
  }
  
  if (song.uploader) {
    embed.addFields({ name: 'Uploader', value: song.uploader.name || 'Unknown', inline: true });
  }
  
  return embed;
}

/**
 * Creates a queue embed
 * @param {Object} queue - The queue object from DisTube
 * @returns {EmbedBuilder} The created embed
 */
function createQueueEmbed(queue) {
  const currentSong = queue.songs[0];
  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('🎶 Current Queue')
    .setDescription(`Now Playing: [${currentSong.name}](${currentSong.url}) [${formatDuration(currentSong.duration)}]`);
  
  if (currentSong.thumbnail) {
    embed.setThumbnail(currentSong.thumbnail);
  }
  
  // Display up to 10 songs in the queue
  if (queue.songs.length > 1) {
    let queueText = '';
    const songsToShow = queue.songs.slice(1, 11); // Get next 10 songs
    
    songsToShow.forEach((song, index) => {
      queueText += `${index + 1}. [${song.name}](${song.url}) [${formatDuration(song.duration)}]\n`;
    });
    
    if (queue.songs.length > 11) {
      queueText += `\nAnd ${queue.songs.length - 11} more song(s)...`;
    }
    
    embed.addFields(
      { name: 'Up Next', value: queueText }
    );
  } else {
    embed.addFields(
      { name: 'Up Next', value: 'No songs in the queue!' }
    );
  }
  
  // Add total queue duration
  const totalDuration = queue.songs.reduce((total, song) => total + song.duration, 0);
  embed.addFields(
    { name: 'Queue Info', value: `${queue.songs.length} song(s) - ${formatDuration(totalDuration)}` }
  );
  
  return embed;
}

/**
 * Creates a search results embed
 * @param {Array} results - The search results
 * @param {string} query - The search query
 * @returns {EmbedBuilder} The created embed
 */
function createSearchResultsEmbed(results, query) {
  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('🔍 Search Results')
    .setDescription(`Here are the results for: **${query}**\n\nSelect a song by clicking the corresponding button.`)
    .setFooter({ text: 'Expires in 30 seconds' });
  
  results.forEach((result, index) => {
    const durationText = result.duration ? formatDuration(result.duration) : 'Unknown duration';
    const channelText = result.channel?.name || 'Unknown channel';
    const viewsText = result.views ? `${formatViews(result.views)} views` : '';
    
    embed.addFields({
      name: `${index + 1}. ${result.title}`,
      value: `[${durationText}] by ${channelText} ${viewsText ? `| ${viewsText}` : ''}`,
    });
  });
  
  return embed;
}

/**
 * Formats seconds into a readable duration string
 * @param {number} seconds - Duration in seconds
 * @returns {string} Formatted duration
 */
function formatDuration(seconds) {
  if (!seconds || isNaN(seconds)) return 'Unknown';
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  } else {
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  }
}

/**
 * Formats view count with K, M abbreviations
 * @param {number} views - View count
 * @returns {string} Formatted view count
 */
function formatViews(views) {
  if (!views || isNaN(views)) return 'Unknown';
  
  if (views >= 1000000) {
    return `${(views / 1000000).toFixed(1)}M`;
  } else if (views >= 1000) {
    return `${(views / 1000).toFixed(1)}K`;
  } else {
    return views.toString();
  }
}

module.exports = {
  createEmbed,
  createSongEmbed,
  createQueueEmbed,
  createSearchResultsEmbed,
  formatDuration,
  formatViews
};