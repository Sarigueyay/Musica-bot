const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);

/**
 * Busca videos en YouTube usando yt-dlp
 * @param {string} query - Término de búsqueda
 * @param {number} limit - Número máximo de resultados (default: 10)
 * @returns {Promise<Array>} - Array de resultados
 */
async function searchYouTube(query, limit = 10) {
  try {
    // Ruta completa a yt-dlp
    const ytDlpPath = '/nix/store/mj7z8g8zfm3nd2ihymkk83czk9yz4xzd-python3.11-yt-dlp-2024.5.27/bin/yt-dlp';
    
    // Construir el comando para yt-dlp con ruta absoluta
    const command = `${ytDlpPath} "ytsearch${limit}:${query.replace(/"/g, '\\"')}" --dump-json --flat-playlist`;
    
    console.log(`Executing search with command: ${command}`);
    
    // Ejecutar el comando y obtener la salida JSON
    const { stdout, stderr } = await execAsync(command, { maxBuffer: 1024 * 1024 * 10 }); // 10MB buffer
    
    if (stderr) {
      console.error('Error in yt-dlp search:', stderr);
    }
    
    // Parsear los resultados (uno por línea)
    const results = stdout.trim().split('\n').map(line => {
      try {
        return JSON.parse(line);
      } catch (e) {
        console.error('Error parsing yt-dlp result line:', e);
        return null;
      }
    }).filter(Boolean); // Eliminar resultados nulos
    
    // Formatear resultados para uso fácil
    return results.map(result => ({
      title: result.title || 'Unknown Title',
      url: result.webpage_url || result.url || `https://www.youtube.com/watch?v=${result.id}`,
      id: result.id,
      duration: result.duration,
      thumbnail: result.thumbnail || `https://i.ytimg.com/vi/${result.id}/hqdefault.jpg`,
      channel: {
        name: result.channel || result.uploader || 'Unknown Channel',
        url: result.channel_url || result.uploader_url || 'https://www.youtube.com'
      },
      views: result.view_count,
      uploaded: result.upload_date
    }));
  } catch (error) {
    console.error('Error performing YouTube search:', error);
    return [];
  }
}

module.exports = { searchYouTube };