require('dotenv').config();
const { Client, GatewayIntentBits, Collection } = require('discord.js');
const { DisTube } = require('distube');
const { SpotifyPlugin } = require('@distube/spotify');
const { SoundCloudPlugin } = require('@distube/soundcloud');
const { YtDlpPlugin } = require('@distube/yt-dlp');
const fs = require('fs');
const path = require('path');

// Create Discord client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// Configuración para ffmpeg

// Importar la utilidad de configuración de ffmpeg
const { setupFFmpeg } = require('./utils/ffmpeg-setup');

// Configurar ffmpeg en el entorno antes de iniciar DisTube
const ffmpegPath = setupFFmpeg();

// Ruta a yt-dlp global
const ytDlpPath = '/nix/store/mj7z8g8zfm3nd2ihymkk83czk9yz4xzd-python3.11-yt-dlp-2024.5.27/bin/yt-dlp';

// Configurar DisTube con opciones mínimas
const distube = new DisTube(client, {
  plugins: [
    new SpotifyPlugin(),
    new SoundCloudPlugin(),
    new YtDlpPlugin({ 
      update: false,
      // Usar la ruta absoluta a yt-dlp
      ytdlpPath: ytDlpPath
    })
  ],
  // Solo usar opciones comprobadas para esta versión
  nsfw: true // Incluir contenido para mayores
});

// Establecer la propiedad distube en el cliente
client.distube = distube;

// Collection for commands
client.commands = new Collection();
const loadedCommands = new Set(); // Para evitar duplicados

// Load commands
const commandsPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(commandsPath);

for (const folder of commandFolders) {
  const folderPath = path.join(commandsPath, folder);
  
  // Verificar que es un directorio
  if (!fs.lstatSync(folderPath).isDirectory()) continue;
  
  const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
  
  for (const file of commandFiles) {
    const filePath = path.join(folderPath, file);
    // Limpiar el caché del módulo para evitar duplicados
    delete require.cache[require.resolve(filePath)];
    
    // Cargar el comando
    const command = require(filePath);
    
    if ('data' in command && 'execute' in command) {
      const commandName = command.data.name;
      
      // Evitar cargar comandos duplicados
      if (!loadedCommands.has(commandName)) {
        client.commands.set(commandName, command);
        loadedCommands.add(commandName);
        console.log(`Loaded command: ${commandName}`);
      } else {
        console.log(`Skipping duplicate command: ${commandName}`);
      }
    } else {
      console.log(`[WARNING] The command at ${filePath} is missing required "data" or "execute" property.`);
    }
  }
}

// Load events
const eventsPath = path.join(__dirname, 'events');
const eventFolders = fs.readdirSync(eventsPath);
const loadedEvents = new Set(); // Para evitar duplicados

for (const folder of eventFolders) {
  const folderPath = path.join(eventsPath, folder);
  
  if (fs.lstatSync(folderPath).isDirectory()) {
    // Directory with events for a specific category (like 'distube')
    const eventFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
    
    for (const file of eventFiles) {
      const filePath = path.join(folderPath, file);
      // Limpiar caché para evitar duplicados
      delete require.cache[require.resolve(filePath)];
      const event = require(filePath);
      
      if (folder === 'distube') {
        const eventKey = `distube:${event.name}`;
        if (!loadedEvents.has(eventKey)) {
          if (event.once) {
            client.distube.once(event.name, (...args) => event.execute(...args));
          } else {
            client.distube.on(event.name, (...args) => event.execute(...args));
          }
          loadedEvents.add(eventKey);
          console.log(`Loaded DisTube event: ${event.name}`);
        } else {
          console.log(`Skipping duplicate DisTube event: ${event.name}`);
        }
      }
    }
  } else if (folder.endsWith('.js')) {
    // Regular client event
    const filePath = path.join(eventsPath, folder);
    delete require.cache[require.resolve(filePath)];
    const event = require(filePath);
    
    const eventKey = `client:${event.name}`;
    if (!loadedEvents.has(eventKey)) {
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args));
      } else {
        client.on(event.name, (...args) => event.execute(...args));
      }
      loadedEvents.add(eventKey);
      console.log(`Loaded client event: ${event.name}`);
    } else {
      console.log(`Skipping duplicate client event: ${event.name}`);
    }
  }
}

// Log in to Discord
const TOKEN = process.env.DISCORD_TOKEN;
if (!TOKEN) {
  console.error('Discord token is not provided! Please add your bot token to the .env file.');
  process.exit(1);
}

client.login(TOKEN).catch(error => {
  console.error('Failed to log in to Discord:', error);
  process.exit(1);
});

// Error handling for unhandled rejections
process.on('unhandledRejection', error => {
  console.error('Unhandled promise rejection:', error);
});
